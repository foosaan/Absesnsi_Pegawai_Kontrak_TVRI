<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Manajemen Pegawai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900">
                    <i class="fas fa-users text-blue-600 dark:text-blue-400"></i>
                </div>
                <div>
                    <h1 class="page-title dark:page-title-dark">Data Pegawai</h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        Kelola data kepegawaian
                    </p>
                </div>
            </div>
            <div class="flex gap-2">
                <a href="<?php echo e(route('staff.psdm.users.import')); ?>" class="btn btn-success">
                    <i class="fas fa-file-excel"></i>
                    <span class="hidden sm:inline">Import Excel</span>
                </a>
                <a href="<?php echo e(route('staff.psdm.users.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i>
                    <span class="hidden sm:inline">Tambah Pegawai</span>
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('staff.psdm.users')); ?>" class="flex flex-wrap items-end gap-4">
                <div class="form-group mb-0 flex-1 min-w-48">
                    <label class="form-label">Cari Pegawai</label>
                    <div class="relative">
                        <i class="fas fa-search form-control-icon"></i>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                               class="form-control form-control-with-icon" 
                               placeholder="Nama atau Email...">
                    </div>
                </div>

            </form>
        </div>
    </div>

    
    <div x-data="{
        selectedIds: [],
        allIds: <?php echo e(json_encode($users->pluck('id')->toArray())); ?>,
        get allSelected() { return this.allIds.length > 0 && this.selectedIds.length === this.allIds.length },
        get someSelected() { return this.selectedIds.length > 0 },
        toggleAll() {
            if (this.allSelected) {
                this.selectedIds = [];
            } else {
                this.selectedIds = [...this.allIds];
            }
        },
        toggleId(id) {
            const idx = this.selectedIds.indexOf(id);
            if (idx > -1) { this.selectedIds.splice(idx, 1); }
            else { this.selectedIds.push(id); }
        }
    }">
        
        <div x-show="someSelected" 
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 translate-y-2"
             x-transition:enter-end="opacity-100 translate-y-0"
             x-transition:leave="transition ease-in duration-150"
             x-transition:leave-start="opacity-100 translate-y-0"
             x-transition:leave-end="opacity-0 translate-y-2"
             x-cloak
             class="mb-4">
            <div class="card border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/20">
                <div class="card-body flex items-center justify-between py-3">
                    <div class="flex items-center gap-3">
                        <div class="flex h-8 w-8 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/50">
                            <i class="fas fa-check-double text-sm text-red-600 dark:text-red-400"></i>
                        </div>
                        <span class="text-sm font-medium text-red-800 dark:text-red-300">
                            <span x-text="selectedIds.length"></span> pegawai dipilih
                        </span>
                    </div>
                    <div class="flex items-center gap-2">
                        <button @click="selectedIds = []" class="btn btn-sm btn-secondary">
                            Batal
                        </button>
                        <form method="POST" action="<?php echo e(route('staff.psdm.users.bulk-delete')); ?>"
                              data-confirm="Yakin ingin menghapus semua pegawai yang dipilih? Semua data terkait (absensi, gaji, cuti, dll) juga akan dihapus!"
                              data-confirm-title="Konfirmasi Hapus Massal">
                            <?php echo csrf_field(); ?>
                            <template x-for="id in selectedIds" :key="id">
                                <input type="hidden" name="user_ids[]" :value="id">
                            </template>
                            <button type="submit" class="btn btn-sm btn-danger">
                                <i class="fas fa-trash mr-1"></i>
                                Hapus (<span x-text="selectedIds.length"></span>)
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="w-10">
                                <input type="checkbox" 
                                       class="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-slate-600 dark:bg-slate-700 cursor-pointer"
                                       @click="toggleAll()"
                                       :checked="allSelected"
                                       :indeterminate="someSelected && !allSelected">
                            </th>
                            <th class="w-12">No</th>
                            <th>Identitas</th>
                            <th>Posisi</th>
                            <th>Status</th>
                            <th>Jenis Kelamin</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="dark:text-gray-300">
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr :class="selectedIds.includes(<?php echo e($user->id); ?>) ? 'bg-blue-50 dark:bg-blue-900/10' : ''">
                            <td>
                                <input type="checkbox" 
                                       class="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-slate-600 dark:bg-slate-700 cursor-pointer"
                                       value="<?php echo e($user->id); ?>"
                                       @click="toggleId(<?php echo e($user->id); ?>)"
                                       :checked="selectedIds.includes(<?php echo e($user->id); ?>)">
                            </td>
                            <td><?php echo e($users->firstItem() + $index); ?></td>
                            <td>
                                <div class="flex items-center gap-3">
                                    <div class="avatar avatar-sm bg-blue-600 text-white">
                                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900 dark:text-white"><?php echo e($user->name); ?></p>
                                        <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($user->nip ?? 'Belum ada NIP'); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="text-sm font-medium text-gray-900 dark:text-white"><?php echo e($user->jabatan ?? '-'); ?></p>
                                <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($user->bagian ?? '-'); ?></p>
                            </td>
                            <td>
                                <span class="badge badge-success"><?php echo e($user->status_pegawai ?? 'Aktif'); ?></span>
                            </td>
                            <td>
                                <?php if($user->jenis_kelamin == 'L'): ?>
                                    <span class="badge bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">Laki-laki</span>
                                <?php elseif($user->jenis_kelamin == 'P'): ?>
                                    <span class="badge bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300">Perempuan</span>
                                <?php else: ?>
                                    <span class="text-gray-400">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <a href="<?php echo e(route('staff.psdm.users.edit', $user)); ?>" 
                                       class="btn btn-sm btn-warning btn-icon" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('staff.psdm.users.delete', $user)); ?>" method="POST"
                                          data-confirm="Yakin ingin menghapus pegawai ini? Tindakan ini tidak dapat dibatalkan." data-confirm-title="Konfirmasi Hapus">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger btn-icon" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-8 text-gray-500 dark:text-gray-400">
                                <i class="fas fa-users-slash text-4xl mb-3 opacity-50"></i>
                                <p>Tidak ada data pegawai ditemukan</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($users->hasPages()): ?>
            <div class="card-body border-t dark:border-slate-700">
                <?php echo e($users->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/psdm/users/index.blade.php ENDPATH**/ ?>