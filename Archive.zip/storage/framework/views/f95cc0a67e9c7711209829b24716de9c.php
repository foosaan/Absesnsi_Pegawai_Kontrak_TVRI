<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Dashboard Keuangan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-3">
            <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-900">
                <i class="fas fa-chart-line text-emerald-600 dark:text-emerald-400"></i>
            </div>
            <div>
                <h1 class="page-title dark:page-title-dark">Dashboard Keuangan</h1>
                <p class="text-sm text-gray-500 dark:text-gray-400">Selamat datang, <?php echo e(auth()->user()->name); ?></p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        <div class="stat-card">
            <div>
                <p class="stat-card-label">Total Karyawan</p>
                <p class="stat-card-value"><?php echo e($totalUsers ?? 0); ?></p>
            </div>
            <div class="stat-card-icon bg-blue-100 dark:bg-blue-900">
                <i class="fas fa-users text-xl text-blue-600 dark:text-blue-400"></i>
            </div>
        </div>

        <div class="stat-card">
            <div>
                <p class="stat-card-label">Total Gaji Bulan Ini</p>
                <p class="stat-card-value text-lg">Rp <?php echo e(number_format($totalSalaryThisMonth ?? 0, 0, ',', '.')); ?></p>
            </div>
            <div class="stat-card-icon bg-emerald-100 dark:bg-emerald-900">
                <i class="fas fa-money-bill-wave text-xl text-emerald-600 dark:text-emerald-400"></i>
            </div>
        </div>

        <div class="stat-card">
            <div>
                <p class="stat-card-label">Sudah Dibayar</p>
                <p class="stat-card-value"><?php echo e($paidCount ?? 0); ?></p>
                <?php if(($paidCount ?? 0) > 0): ?>
                <span class="stat-trend-up">
                    <i class="fas fa-check"></i> Selesai
                </span>
                <?php endif; ?>
            </div>
            <div class="stat-card-icon bg-green-100 dark:bg-green-900">
                <i class="fas fa-check-circle text-xl text-green-600 dark:text-green-400"></i>
            </div>
        </div>

        <div class="stat-card">
            <div>
                <p class="stat-card-label">Belum Diinput</p>
                <p class="stat-card-value"><?php echo e($pendingCount ?? 0); ?></p>
                <?php if(($pendingCount ?? 0) > 0): ?>
                <span class="stat-trend-down">
                    <i class="fas fa-clock"></i> Pending
                </span>
                <?php endif; ?>
            </div>
            <div class="stat-card-icon bg-amber-100 dark:bg-amber-900">
                <i class="fas fa-hourglass-half text-xl text-amber-600 dark:text-amber-400"></i>
            </div>
        </div>
    </div>

    
    <div class="card dark:card-dark mb-6">
        <div class="card-header dark:card-header-dark">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-bolt text-amber-500 mr-2"></i>
                Aksi Cepat
            </h3>
        </div>
        <div class="card-body">
            <div class="grid gap-3 sm:grid-cols-3">
                <a href="<?php echo e(route('staff.keuangan.users')); ?>" class="btn btn-success w-full justify-start">
                    <i class="fas fa-edit"></i>
                    <span>Input Gaji</span>
                </a>
                <a href="<?php echo e(route('staff.keuangan.salaries')); ?>" class="btn btn-primary w-full justify-start">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Data Gaji</span>
                </a>
                <a href="<?php echo e(route('staff.keuangan.deductions.index')); ?>" class="btn btn-secondary w-full justify-start">
                    <i class="fas fa-minus-circle"></i>
                    <span>Jenis Potongan</span>
                </a>
            </div>
        </div>
    </div>

    
    <div class="card dark:card-dark">
        <div class="card-header dark:card-header-dark flex items-center justify-between">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-clock text-blue-500 mr-2"></i>
                Data Gaji Terbaru
            </h3>
            <a href="<?php echo e(route('staff.keuangan.salaries')); ?>" class="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="table dark:table-dark">
                <thead>
                    <tr>
                        <th>Karyawan</th>
                        <th>Periode</th>
                        <th>Gaji Diterima</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="dark:text-gray-300">
                    <?php $__empty_1 = true; $__currentLoopData = $recentSalaries ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                <div class="avatar avatar-sm bg-blue-600 text-white">
                                    <?php echo e(strtoupper(substr($salary->user->name ?? 'N', 0, 1))); ?>

                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white"><?php echo e($salary->user->name ?? 'N/A'); ?></p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($salary->user->nip ?? '-'); ?></p>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php echo e(\Carbon\Carbon::create()->month((int) $salary->month)->translatedFormat('M')); ?> <?php echo e($salary->year); ?>

                        </td>
                        <td class="font-medium text-gray-900 dark:text-white">
                            Rp <?php echo e(number_format($salary->final_salary, 0, ',', '.')); ?>

                        </td>
                        <td>
                            <?php if($salary->status === 'paid'): ?>
                                <span class="badge badge-success">Dibayar</span>
                            <?php elseif($salary->status === 'approved'): ?>
                                <span class="badge badge-info">Disetujui</span>
                            <?php else: ?>
                                <span class="badge badge-warning">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('staff.keuangan.salaries.show', $salary)); ?>" class="btn btn-sm btn-primary btn-icon">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-8 text-gray-500 dark:text-gray-400">
                            <i class="fas fa-inbox text-4xl mb-3 opacity-50"></i>
                            <p>Belum ada data gaji</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/keuangan/dashboard.blade.php ENDPATH**/ ?>