<section>
    <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">
        Perbarui nama dan alamat email akun Anda.
    </p>

    <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
    </form>

    <form method="post" action="<?php echo e(route('profile.update')); ?>" class="space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>

        <div class="form-group">
            <label for="name" class="form-label dark:text-gray-300">Nama</label>
            <div class="relative">
                <i class="fas fa-user form-control-icon"></i>
                <input id="name" name="name" type="text" 
                       class="form-control form-control-with-icon" 
                       value="<?php echo e(old('name', $user->name)); ?>" required autofocus autocomplete="name">
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="email" class="form-label dark:text-gray-300">Email</label>
            <div class="relative">
                <i class="fas fa-envelope form-control-icon"></i>
                <input id="email" name="email" type="email" 
                       class="form-control form-control-with-icon" 
                       value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username">
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
                <div class="mt-2">
                    <p class="text-sm text-gray-600 dark:text-gray-400">
                        Email Anda belum diverifikasi.
                        <button form="send-verification" class="underline text-blue-600 hover:text-blue-800 dark:text-blue-400">
                            Klik untuk mengirim ulang email verifikasi.
                        </button>
                    </p>
                    <?php if(session('status') === 'verification-link-sent'): ?>
                        <p class="mt-2 text-sm text-green-600 dark:text-green-400">
                            <i class="fas fa-check-circle mr-1"></i> Link verifikasi baru telah dikirim.
                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="flex items-center gap-4 pt-2">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save mr-1"></i> Simpan
            </button>

            <?php if(session('status') === 'profile-updated'): ?>
                <p x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 2000)"
                   class="text-sm text-green-600 dark:text-green-400">
                    <i class="fas fa-check-circle mr-1"></i> Tersimpan.
                </p>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>