<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Manajemen Dinas Luar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900">
                    <i class="fas fa-briefcase text-blue-600 dark:text-blue-400"></i>
                </div>
                <div>
                    <h1 class="page-title dark:page-title-dark">Manajemen Dinas Luar</h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        Kelola pengajuan dinas luar karyawan
                        <?php if($pendingCount > 0): ?>
                            <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400">
                                <?php echo e($pendingCount); ?> menunggu
                            </span>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('staff.psdm.business-trips')); ?>" class="flex flex-wrap items-end gap-4">
                <div class="form-group mb-0">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control" onchange="this.form.submit()">
                        <option value="">Semua Status</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Menunggu</option>
                        <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Disetujui</option>
                        <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>Ditolak</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Karyawan</th>
                        <th>Tujuan</th>
                        <th>Tanggal</th>
                        <th>Durasi</th>
                        <th>Keperluan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="dark:text-gray-300">
                    <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                <div class="avatar avatar-sm bg-blue-600 text-white">
                                    <?php echo e(strtoupper(substr($trip->user->name ?? 'U', 0, 1))); ?>

                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white"><?php echo e($trip->user->name ?? '-'); ?></p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($trip->user->nip ?? '-'); ?></p>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300 font-medium">
                                <?php echo e($trip->destination); ?>

                            </span>
                        </td>
                        <td>
                            <div class="text-sm">
                                <p><?php echo e($trip->start_date->format('d M Y')); ?></p>
                                <p class="text-xs text-gray-500">s/d <?php echo e($trip->end_date->format('d M Y')); ?></p>
                            </div>
                        </td>
                        <td>
                            <span class="font-medium"><?php echo e($trip->total_days); ?> hari</span>
                        </td>
                        <td>
                            <p class="text-sm text-gray-600 dark:text-gray-400 max-w-xs truncate" title="<?php echo e($trip->purpose); ?>">
                                <?php echo e($trip->purpose); ?>

                            </p>
                        </td>
                        <td>
                            <?php if($trip->status === 'pending'): ?>
                                <span class="badge badge-warning">Menunggu</span>
                            <?php elseif($trip->status === 'approved'): ?>
                                <span class="badge badge-success">Disetujui</span>
                                <?php if($trip->approver): ?>
                                    <p class="text-[10px] text-gray-500 mt-0.5">oleh <?php echo e($trip->approver->name); ?></p>
                                <?php endif; ?>
                            <?php elseif($trip->status === 'rejected'): ?>
                                <span class="badge badge-danger">Ditolak</span>
                                <?php if($trip->rejection_reason): ?>
                                    <p class="text-[10px] text-gray-500 mt-0.5" title="<?php echo e($trip->rejection_reason); ?>"><?php echo e(Str::limit($trip->rejection_reason, 30)); ?></p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($trip->status === 'pending'): ?>
                                <div class="flex items-center gap-2">
                                    
                                    <form method="POST" action="<?php echo e(route('staff.psdm.business-trips.approve', $trip)); ?>" onsubmit="return confirm('Setujui dinas luar <?php echo e($trip->user->name); ?>?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-success btn-sm" title="Setujui">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </form>

                                    
                                    <button type="button" 
                                            class="btn btn-danger btn-sm"
                                            title="Tolak"
                                            onclick="document.getElementById('reject-modal-<?php echo e($trip->id); ?>').classList.remove('hidden')">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>

                                
                                <div id="reject-modal-<?php echo e($trip->id); ?>" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                                    <div class="bg-white dark:bg-slate-800 rounded-xl shadow-xl max-w-md w-full p-6">
                                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Tolak Dinas Luar</h3>
                                        <p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                            Tolak pengajuan dinas luar <strong><?php echo e($trip->user->name); ?></strong> 
                                            ke <?php echo e($trip->destination); ?> (<?php echo e($trip->start_date->format('d M')); ?> - <?php echo e($trip->end_date->format('d M Y')); ?>)?
                                        </p>
                                        <form method="POST" action="<?php echo e(route('staff.psdm.business-trips.reject', $trip)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <div class="form-group">
                                                <label class="form-label">Alasan Penolakan <span class="text-red-500">*</span></label>
                                                <textarea name="rejection_reason" rows="3" class="form-control" required placeholder="Masukkan alasan penolakan..."></textarea>
                                            </div>
                                            <div class="flex justify-end gap-3 mt-4">
                                                <button type="button" class="btn btn-secondary" 
                                                        onclick="document.getElementById('reject-modal-<?php echo e($trip->id); ?>').classList.add('hidden')">
                                                    Batal
                                                </button>
                                                <button type="submit" class="btn btn-danger">Tolak Dinas Luar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <span class="text-xs text-gray-400">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-8 text-gray-500 dark:text-gray-400">
                            <i class="fas fa-briefcase text-4xl mb-3 opacity-50"></i>
                            <p>Tidak ada pengajuan dinas luar</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($trips->hasPages()): ?>
        <div class="card-body border-t dark:border-slate-700">
            <?php echo e($trips->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/psdm/business-trips/index.blade.php ENDPATH**/ ?>