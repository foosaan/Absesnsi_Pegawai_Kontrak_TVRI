<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => ''.e($type->name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('staff.psdm.master-data')); ?>" class="btn btn-secondary btn-icon">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div>
                <h1 class="page-title dark:page-title-dark"><?php echo e($type->name); ?></h1>
                <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($type->description ?? 'Master Data PSDM'); ?></p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('staff.psdm.master-data.values.store', $type)); ?>" class="flex flex-wrap items-end gap-4">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-0 flex-1 min-w-48">
                    <label class="form-label">Nilai Baru</label>
                    <input type="text" name="value" class="form-control" 
                           placeholder="Masukkan nilai..." required>
                </div>
                <div class="form-group mb-0 flex-1 min-w-48">
                    <label class="form-label">Deskripsi (opsional)</label>
                    <input type="text" name="description" class="form-control" 
                           placeholder="Keterangan singkat...">
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Tambah
                </button>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th class="w-16">No</th>
                        <th>Nilai</th>
                        <th>Deskripsi</th>
                        <th>Status</th>
                        <th class="text-center w-24">Aksi</th>
                    </tr>
                </thead>
                <tbody class="dark:text-gray-300">
                    <?php $__empty_1 = true; $__currentLoopData = $type->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td class="font-medium text-gray-900 dark:text-white"><?php echo e($value->value); ?></td>
                        <td><?php echo e($value->description ?? '-'); ?></td>
                        <td>
                            <?php if($value->is_active): ?>
                                <span class="badge badge-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">Non-Aktif</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <form action="<?php echo e(route('staff.psdm.master-data.values.destroy', $value)); ?>" method="POST"
                                  data-confirm="Hapus nilai <?php echo e($value->value); ?>?" data-confirm-title="Konfirmasi Hapus">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger btn-icon" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-8 text-gray-500 dark:text-gray-400">
                            <i class="fas fa-inbox text-4xl mb-3 opacity-50"></i>
                            <p>Belum ada data. Tambahkan menggunakan form di atas.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/psdm/master-data/show.blade.php ENDPATH**/ ?>