<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Pengumuman'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100 dark:bg-red-900">
                    <i class="fas fa-bullhorn text-red-600 dark:text-red-400"></i>
                </div>
                <div>
                    <h1 class="page-title dark:page-title-dark">Pengumuman</h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        Kelola informasi penting untuk pegawai
                    </p>
                </div>
            </div>
            <a href="<?php echo e(route('staff.psdm.announcements.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i>
                <span>Buat Pengumuman</span>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="grid gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card dark:card-dark <?php echo e(!$announcement->is_active ? 'opacity-75' : ''); ?>">
            <div class="card-body">
                <div class="flex items-start justify-between gap-4">
                    <div class="flex-1">
                        <div class="flex items-center gap-2 mb-1">
                            <?php if(!$announcement->is_active): ?>
                                <span class="badge badge-secondary">Non-Aktif</span>
                            <?php endif; ?>
                            <h3 class="font-semibold text-lg text-gray-900 dark:text-white">
                                <?php echo e($announcement->title); ?>

                            </h3>
                        </div>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mb-3">
                            Diposting oleh <span class="font-medium text-gray-700 dark:text-gray-300"><?php echo e($announcement->creator->name ?? 'Admin'); ?></span>
                            &bull; <?php echo e($announcement->created_at->diffForHumans()); ?>

                        </p>
                        <div class="prose dark:prose-invert max-w-none text-gray-600 dark:text-gray-300 text-sm">
                            <?php echo nl2br(e($announcement->content)); ?>

                        </div>
                    </div>
                    
                    <div class="flex flex-col gap-2">
                        <a href="<?php echo e(route('staff.psdm.announcements.edit', $announcement)); ?>" 
                           class="btn btn-sm btn-secondary btn-icon" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form action="<?php echo e(route('staff.psdm.announcements.toggle', $announcement)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-sm <?php echo e($announcement->is_active ? 'btn-warning' : 'btn-success'); ?> btn-icon"
                                    title="<?php echo e($announcement->is_active ? 'Non-aktifkan' : 'Aktifkan'); ?>">
                                <i class="fas <?php echo e($announcement->is_active ? 'fa-eye-slash' : 'fa-eye'); ?>"></i>
                            </button>
                        </form>
                        <form action="<?php echo e(route('staff.psdm.announcements.delete', $announcement)); ?>" method="POST"
                              data-confirm="Hapus pengumuman ini?" data-confirm-title="Konfirmasi Hapus">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger btn-icon" title="Hapus">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card dark:card-dark py-12 text-center">
            <div class="flex flex-col items-center justify-center">
                <div class="bg-gray-100 dark:bg-slate-700 rounded-full h-16 w-16 flex items-center justify-center mb-4">
                    <i class="fas fa-bullhorn text-3xl text-gray-400"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 dark:text-white">Belum ada pengumuman</h3>
                <p class="text-gray-500 dark:text-gray-400 max-w-sm mt-1">
                    Buat pengumuman baru untuk memberitahu informasi penting kepada pegawai.
                </p>
                <a href="<?php echo e(route('staff.psdm.announcements.create')); ?>" class="btn btn-primary mt-4">
                    <i class="fas fa-plus"></i> Buat Pengumuman
                </a>
            </div>
        </div>
        <?php endif; ?>

        <div class="mt-4">
            <?php echo e($announcements->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/psdm/announcements/index.blade.php ENDPATH**/ ?>