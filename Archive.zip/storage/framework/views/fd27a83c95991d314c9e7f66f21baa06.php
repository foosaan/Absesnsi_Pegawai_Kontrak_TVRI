<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Edit Gaji - '.e($salary->user->name ?? 'N/A').''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-100 dark:bg-amber-900">
                    <i class="fas fa-edit text-amber-600 dark:text-amber-400"></i>
                </div>
                <div>
                    <h1 class="page-title dark:page-title-dark">Edit Data Gaji</h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        <?php echo e(\Carbon\Carbon::create()->month((int) $salary->month)->translatedFormat('F')); ?> <?php echo e($salary->year); ?>

                    </p>
                </div>
            </div>
            <a href="<?php echo e(route('staff.keuangan.salaries.show', $salary)); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i>
                <span>Kembali</span>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="grid gap-6 lg:grid-cols-3">
        
        <div class="lg:col-span-2">
            <form method="POST" action="<?php echo e(route('staff.keuangan.salaries.update', $salary)); ?>" id="editSalaryForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="card dark:card-dark mb-6">
                    <div class="card-header dark:card-header-dark">
                        <h3 class="font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-user text-blue-500 mr-2"></i>
                            Informasi Karyawan
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="grid gap-4 sm:grid-cols-2">
                            <div>
                                <label class="form-label">Nama</label>
                                <p class="font-medium text-gray-900 dark:text-white"><?php echo e($salary->user->name ?? 'N/A'); ?></p>
                            </div>
                            <div>
                                <label class="form-label">NIP</label>
                                <p class="font-medium text-gray-900 dark:text-white"><?php echo e($salary->user->nip ?? '-'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card dark:card-dark mb-6">
                    <div class="card-header dark:card-header-dark">
                        <h3 class="font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-money-check-alt text-emerald-500 mr-2"></i>
                            Data Gaji
                        </h3>
                    </div>
                    <div class="card-body space-y-4">
                        <div class="form-group">
                            <label for="base_salary" class="form-label">Gaji Pokok <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">Rp</span>
                                <input type="number" name="base_salary" id="base_salary" 
                                       class="form-control pl-10" 
                                       value="<?php echo e(old('base_salary', $salary->base_salary)); ?>" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="potongan_kppn" class="form-label">Potongan KPPN</label>
                            <div class="relative">
                                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">Rp</span>
                                <input type="number" name="potongan_kppn" id="potongan_kppn" 
                                       class="form-control pl-10" 
                                       value="<?php echo e(old('potongan_kppn', $salary->potongan_kppn)); ?>" min="0">
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card dark:card-dark mb-6">
                    <div class="card-header dark:card-header-dark">
                        <h3 class="font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-minus-circle text-red-500 mr-2"></i>
                            Potongan Intern
                        </h3>
                    </div>
                    <div class="card-body space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $deductionTypes ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $existingDeduction = $salary->salaryDeductions->where('deduction_type_id', $type->id)->first();
                                $amount = $existingDeduction ? $existingDeduction->amount : 0;
                            ?>
                            <div class="form-group">
                                <input type="hidden" name="deduction_ids[]" value="<?php echo e($type->id); ?>">
                                <label class="form-label"><?php echo e($type->name); ?></label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">Rp</span>
                                    <input type="number" name="deduction_amounts[]" 
                                           class="form-control pl-10 deduction-input" 
                                           value="<?php echo e($amount); ?>" min="0">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-500 dark:text-gray-400 text-center py-4">
                                Tidak ada jenis potongan. 
                                <a href="<?php echo e(route('staff.keuangan.deductions.index')); ?>" class="text-blue-600 hover:underline">Tambah jenis potongan</a>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                
                <button type="submit" class="btn btn-warning btn-lg w-full text-white">
                    <i class="fas fa-save"></i>
                    <span>Update Data Gaji</span>
                </button>
            </form>
        </div>

        
        <div class="lg:col-span-1">
            <div class="card dark:card-dark sticky top-20">
                <div class="card-header dark:card-header-dark">
                    <h3 class="font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-calculator text-blue-500 mr-2"></i>
                        Ringkasan
                    </h3>
                </div>
                <div class="card-body space-y-3">
                    <div class="flex justify-between">
                        <span class="text-gray-600 dark:text-gray-400">Periode</span>
                        <span class="font-medium text-gray-900 dark:text-white">
                            <?php echo e(\Carbon\Carbon::create()->month((int) $salary->month)->translatedFormat('F')); ?> <?php echo e($salary->year); ?>

                        </span>
                    </div>
                    <hr class="dark:border-slate-700">
                    <div class="flex justify-between">
                        <span class="text-gray-600 dark:text-gray-400">Gaji Pokok</span>
                        <span class="font-medium text-gray-900 dark:text-white" id="summary-base">Rp 0</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600 dark:text-gray-400">Pot. KPPN</span>
                        <span class="font-medium text-red-600 dark:text-red-400" id="summary-kppn">- Rp 0</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600 dark:text-gray-400">Pot. Intern</span>
                        <span class="font-medium text-red-600 dark:text-red-400" id="summary-intern">- Rp 0</span>
                    </div>
                    <hr class="dark:border-slate-700">
                    <div class="flex justify-between text-lg">
                        <span class="font-semibold text-gray-900 dark:text-white">Total Diterima</span>
                        <span class="font-bold text-emerald-600 dark:text-emerald-400" id="summary-total">Rp 0</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        function formatRupiah(num) {
            return 'Rp ' + num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }

        function calculate() {
            const base = parseInt(document.getElementById('base_salary').value) || 0;
            const kppn = parseInt(document.getElementById('potongan_kppn').value) || 0;
            
            let intern = 0;
            document.querySelectorAll('.deduction-input').forEach(input => {
                intern += parseInt(input.value) || 0;
            });

            const total = base - kppn - intern;

            document.getElementById('summary-base').textContent = formatRupiah(base);
            document.getElementById('summary-kppn').textContent = '- ' + formatRupiah(kppn);
            document.getElementById('summary-intern').textContent = '- ' + formatRupiah(intern);
            document.getElementById('summary-total').textContent = formatRupiah(total);
        }

        document.getElementById('base_salary').addEventListener('input', calculate);
        document.getElementById('potongan_kppn').addEventListener('input', calculate);
        document.querySelectorAll('.deduction-input').forEach(input => {
            input.addEventListener('input', calculate);
        });

        calculate(); // Initial calculation
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/keuangan/salaries/edit.blade.php ENDPATH**/ ?>