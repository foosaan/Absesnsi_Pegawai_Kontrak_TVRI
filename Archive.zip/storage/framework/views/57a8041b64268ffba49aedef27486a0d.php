<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Kelola Admin'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between gap-4">
            <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">Kelola Admin</h1>
            <a href="<?php echo e(route('admin.admins.create')); ?>" class="btn btn-danger">
                <i class="fas fa-plus"></i>
                <span>Tambah Admin</span>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    

    
    <div class="card mb-6">
        <div class="card-body">
            <form method="GET" class="flex flex-wrap items-end gap-4">
                <div class="form-field mb-0 flex-1">
                    <label class="form-label">Cari</label>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                           class="form-control" placeholder="Nama atau email...">
                </div>
                <?php if(request('search')): ?>
                <div class="flex gap-2">
                    <a href="<?php echo e(route('admin.admins')); ?>" class="btn btn-secondary">Reset</a>
                </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Daftar Admin</h3>
        </div>
        <div class="card-body p-0">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th class="text-center">Dibuat</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($admin->id === auth()->id() ? 'bg-blue-50 dark:bg-blue-900/20' : ''); ?>">
                            <td>
                                <div class="font-medium text-gray-900 dark:text-white"><?php echo e($admin->name); ?></div>
                                <?php if($admin->id === auth()->id()): ?>
                                    <span class="text-xs text-blue-500">(Anda)</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-gray-600 dark:text-slate-400"><?php echo e($admin->email); ?></td>
                            <td class="text-center text-sm text-gray-500 dark:text-slate-400">
                                <?php echo e($admin->created_at->format('d M Y')); ?>

                            </td>
                            <td class="text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <a href="<?php echo e(route('admin.admins.edit', $admin)); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-edit"></i>
                                        <span>Edit</span>
                                    </a>
                                    <?php if($admin->id !== auth()->id()): ?>
                                    <form action="<?php echo e(route('admin.admins.delete', $admin)); ?>" method="POST" class="inline"
                                          data-confirm="Yakin ingin menghapus admin <?php echo e($admin->name); ?>?" data-confirm-title="Konfirmasi Hapus">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                            <span>Hapus</span>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-gray-500 dark:text-slate-400 py-8">
                                <i class="fas fa-user-shield text-4xl mb-2 opacity-50"></i>
                                <p>Tidak ada data admin</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <?php if($admins->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($admins->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/admin/admins/index.blade.php ENDPATH**/ ?>