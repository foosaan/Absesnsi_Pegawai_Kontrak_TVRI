<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Pengajuan Cuti'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-100 dark:bg-amber-900">
                    <i class="fas fa-umbrella-beach text-amber-600 dark:text-amber-400"></i>
                </div>
                <div>
                    <h1 class="page-title">Pengajuan Cuti</h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Kelola cuti dan izin Anda</p>
                </div>
            </div>
            <a href="<?php echo e(route('user.leaves.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Ajukan Cuti
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    

    <?php if($leaves->count() > 0): ?>
    <div class="space-y-4">
        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-body">
                <div class="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-3 mb-4">
                    <div class="flex items-center gap-2">
                        <span class="badge badge-secondary"><?php echo e($leave->type_label); ?></span>
                        <span class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($leave->total_days); ?> hari</span>
                    </div>
                    <?php if($leave->status === 'approved'): ?>
                        <span class="badge badge-success"><i class="fas fa-check mr-1"></i>Disetujui</span>
                    <?php elseif($leave->status === 'rejected'): ?>
                        <span class="badge badge-danger"><i class="fas fa-times mr-1"></i>Ditolak</span>
                    <?php else: ?>
                        <span class="badge badge-warning"><i class="fas fa-clock mr-1"></i>Menunggu</span>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <div class="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                        <i class="fas fa-calendar-alt text-blue-500"></i>
                        <span class="font-medium text-gray-900 dark:text-white"><?php echo e($leave->start_date->format('d M Y')); ?></span>
                        <i class="fas fa-arrow-right text-gray-400"></i>
                        <span class="font-medium text-gray-900 dark:text-white"><?php echo e($leave->end_date->format('d M Y')); ?></span>
                    </div>
                </div>
                
                <div class="text-sm text-gray-700 dark:text-gray-300 mb-3">
                    <strong>Alasan:</strong> <?php echo e($leave->reason); ?>

                </div>
                
                <?php if($leave->status === 'rejected' && $leave->rejection_reason): ?>
                <div class="notification notification-danger p-3 text-sm">
                    <strong>Alasan Penolakan:</strong> <?php echo e($leave->rejection_reason); ?>

                </div>
                <?php endif; ?>
                
                <?php if($leave->status === 'pending'): ?>
                <div class="mt-4 pt-3 border-t border-gray-100 dark:border-slate-700">
                    <form action="<?php echo e(route('user.leaves.cancel', $leave)); ?>" method="POST" class="inline"
                          data-confirm="Yakin ingin membatalkan pengajuan cuti ini?" data-confirm-title="Konfirmasi Hapus">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-times"></i> Batalkan Pengajuan
                        </button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <?php if(method_exists($leaves, 'hasPages') && $leaves->hasPages()): ?>
    <div class="mt-6">
        <?php echo e($leaves->links()); ?>

    </div>
    <?php endif; ?>
    
    <?php else: ?>
    <div class="card">
        <div class="card-body text-center py-12">
            <i class="fas fa-umbrella-beach text-6xl text-gray-300 dark:text-gray-600 mb-4"></i>
            <h3 class="font-bold text-lg text-gray-700 dark:text-gray-300 mb-2">Belum Ada Pengajuan Cuti</h3>
            <p class="text-gray-500 dark:text-gray-400 mb-4">Anda belum pernah mengajukan cuti.</p>
            <a href="<?php echo e(route('user.leaves.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Ajukan Cuti Sekarang
            </a>
        </div>
    </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/user/leaves/index.blade.php ENDPATH**/ ?>