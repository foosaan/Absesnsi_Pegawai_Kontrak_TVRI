<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Import Pegawai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('staff.psdm.users')); ?>" class="btn btn-sm btn-secondary">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-900">
                <i class="fas fa-file-excel text-emerald-600 dark:text-emerald-400"></i>
            </div>
            <div>
                <h1 class="page-title dark:page-title-dark">Import Pegawai dari Excel</h1>
                <p class="text-sm text-gray-500 dark:text-gray-400">Upload file Excel untuk menambah pegawai secara massal</p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-header">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-info-circle text-blue-500 mr-2"></i>Format File Excel
            </h3>
        </div>
        <div class="card-body">
            <p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
                File Excel harus memiliki <strong>header di baris pertama</strong> dengan kolom:
            </p>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Kolom</th>
                            <th>Wajib</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody class="dark:text-gray-300">
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">nip</code></td><td><span class="badge badge-danger">Wajib</span></td><td>Nomor Induk Pegawai (unik)</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">nik</code></td><td><span class="badge badge-danger">Wajib</span></td><td>Nomor Induk Kependudukan (unik)</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">nama</code></td><td><span class="badge badge-danger">Wajib</span></td><td>Nama lengkap pegawai</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">email</code></td><td><span class="badge badge-danger">Wajib</span></td><td>Email login (unik)</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">jabatan</code></td><td><span class="badge badge-info">Opsional</span></td><td>Jabatan pegawai</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">bagian</code></td><td><span class="badge badge-info">Opsional</span></td><td>Bagian/divisi</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">status_pegawai</code></td><td><span class="badge badge-info">Opsional</span></td><td>Status pegawai (PNS, Kontrak, dll)</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">jenis_kelamin</code></td><td><span class="badge badge-info">Opsional</span></td><td>L / P atau Laki-laki / Perempuan</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">alamat</code></td><td><span class="badge badge-info">Opsional</span></td><td>Alamat</td></tr>
                        <tr><td><code class="text-sm bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded">tipe_absensi</code></td><td><span class="badge badge-info">Opsional</span></td><td>normal / shift (default: normal)</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                <p class="text-sm text-amber-700 dark:text-amber-400">
                    <i class="fas fa-exclamation-triangle mr-1"></i>
                    <strong>Catatan:</strong> NIP yang sudah terdaftar akan otomatis dilewati (tidak duplikat). 
                    Password default: <code class="bg-amber-100 dark:bg-amber-800 px-1 rounded">password123</code>
                </p>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-upload text-green-500 mr-2"></i>Upload File
            </h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('staff.psdm.users.import.process')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="form-label">File Excel (.xlsx, .xls, .csv)</label>
                    <input type="file" name="file" accept=".xlsx,.xls,.csv"
                           class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="flex gap-3">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-upload mr-1"></i> Import Pegawai
                    </button>
                    <a href="<?php echo e(route('staff.psdm.users')); ?>" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/psdm/users/import.blade.php ENDPATH**/ ?>