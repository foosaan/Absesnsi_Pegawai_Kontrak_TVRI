<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Pengaturan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-3">
            <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                <i class="fas fa-cog text-gray-600 dark:text-gray-400"></i>
            </div>
            <div>
                <h1 class="page-title dark:page-title-dark">Pengaturan</h1>
                <p class="text-sm text-gray-500 dark:text-gray-400">Kelola lokasi absensi dan pengaturan shift</p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>


    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        
        <div class="card">
            <div class="card-header">
                <h3 class="font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-map-marker-alt text-red-500 mr-2"></i>
                    Lokasi & Radius Absensi
                </h3>
            </div>
            <div class="card-body">
                <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">
                    Atur titik lokasi kantor dan radius maksimal untuk absensi karyawan.
                </p>

                <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="office_latitude" class="form-label dark:text-gray-300">Latitude Kantor</label>
                        <div class="relative">
                            <i class="fas fa-map-pin form-control-icon"></i>
                            <input type="number" step="any" id="office_latitude" name="office_latitude" 
                                   value="<?php echo e($settings['office_latitude'] ?? ''); ?>" 
                                   class="form-control form-control-with-icon" 
                                   placeholder="-7.795580" required>
                        </div>
                        <?php $__errorArgs = ['office_latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="office_longitude" class="form-label dark:text-gray-300">Longitude Kantor</label>
                        <div class="relative">
                            <i class="fas fa-map-pin form-control-icon"></i>
                            <input type="number" step="any" id="office_longitude" name="office_longitude" 
                                   value="<?php echo e($settings['office_longitude'] ?? ''); ?>" 
                                   class="form-control form-control-with-icon" 
                                   placeholder="110.365470" required>
                        </div>
                        <?php $__errorArgs = ['office_longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="allowed_radius_meters" class="form-label dark:text-gray-300">Radius Absensi (meter)</label>
                        <div class="relative">
                            <i class="fas fa-bullseye form-control-icon"></i>
                            <input type="number" id="allowed_radius_meters" name="allowed_radius_meters" 
                                   value="<?php echo e($settings['allowed_radius_meters'] ?? 100); ?>" 
                                   class="form-control form-control-with-icon" 
                                   placeholder="100" min="10" required>
                        </div>
                        <p class="text-xs text-gray-400 mt-1">Jarak maksimal dari titik kantor untuk bisa absen</p>
                        <?php $__errorArgs = ['allowed_radius_meters'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="pt-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save mr-1"></i> Simpan Pengaturan
                        </button>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="card">
            <div class="card-header">
                <h3 class="font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-info-circle text-blue-500 mr-2"></i>
                    Info Lokasi Saat Ini
                </h3>
            </div>
            <div class="card-body">
                <div class="space-y-4">
                    <div class="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-slate-700/50">
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Latitude</p>
                            <p class="font-mono font-semibold text-gray-900 dark:text-white"><?php echo e($settings['office_latitude'] ?? 'Belum diatur'); ?></p>
                        </div>
                        <i class="fas fa-map-marker-alt text-red-400"></i>
                    </div>
                    <div class="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-slate-700/50">
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Longitude</p>
                            <p class="font-mono font-semibold text-gray-900 dark:text-white"><?php echo e($settings['office_longitude'] ?? 'Belum diatur'); ?></p>
                        </div>
                        <i class="fas fa-map-marker-alt text-blue-400"></i>
                    </div>
                    <div class="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-slate-700/50">
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Radius Absensi</p>
                            <p class="font-semibold text-gray-900 dark:text-white"><?php echo e($settings['allowed_radius_meters'] ?? '100'); ?> meter</p>
                        </div>
                        <i class="fas fa-bullseye text-green-400"></i>
                    </div>

                    <?php if(isset($settings['office_latitude']) && isset($settings['office_longitude'])): ?>
                    <a href="https://www.google.com/maps?q=<?php echo e($settings['office_latitude']); ?>,<?php echo e($settings['office_longitude']); ?>" 
                       target="_blank" class="btn btn-secondary w-full justify-center">
                        <i class="fas fa-external-link-alt mr-1"></i> Lihat di Google Maps
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-6">
        <div class="card-header">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-clock text-purple-500 mr-2"></i>
                Pengaturan Shift
            </h3>
        </div>
        <div class="card-body">
            <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-4 rounded-xl border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-700/30">
                    <h4 class="font-semibold text-gray-900 dark:text-white mb-3">
                        <i class="fas fa-tag text-purple-400 mr-1"></i> <?php echo e($shift->name); ?>

                    </h4>
                    <form method="POST" action="<?php echo e(route('admin.shift.update', $shift)); ?>" class="space-y-3">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group mb-0">
                            <label class="form-label text-xs dark:text-gray-300">Jam Masuk</label>
                            <input type="time" name="start_time" 
                                   value="<?php echo e($shift->start_time instanceof \Carbon\Carbon ? $shift->start_time->format('H:i') : substr($shift->start_time, 0, 5)); ?>" 
                                   class="form-control text-sm" required>
                        </div>

                        <div class="form-group mb-0">
                            <label class="form-label text-xs dark:text-gray-300">Jam Pulang</label>
                            <input type="time" name="end_time" 
                                   value="<?php echo e($shift->end_time instanceof \Carbon\Carbon ? $shift->end_time->format('H:i') : substr($shift->end_time, 0, 5)); ?>" 
                                   class="form-control text-sm" required>
                        </div>

                        <div class="form-group mb-0">
                            <label class="form-label text-xs dark:text-gray-300">Toleransi (menit)</label>
                            <input type="number" name="tolerance_minutes" 
                                   value="<?php echo e($shift->tolerance_minutes); ?>" 
                                   class="form-control text-sm" min="0" max="120" required>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm w-full">
                            <i class="fas fa-save mr-1"></i> Simpan
                        </button>
                    </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-history text-amber-500 mr-2"></i>
                Log Perubahan Shift
            </h3>
        </div>
        <div class="overflow-x-auto">
            <table class="table">
                <thead>
                    <tr>
                        <th>Waktu</th>
                        <th>Shift</th>
                        <th>Field</th>
                        <th>Nilai Lama</th>
                        <th>Nilai Baru</th>
                        <th>Diubah Oleh</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $shiftLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-sm"><?php echo e($log->created_at->format('d M Y H:i')); ?></td>
                            <td><?php echo e($log->shift->name ?? '-'); ?></td>
                            <td>
                                <span class="badge badge-info"><?php echo e($log->field_name ?? '-'); ?></span>
                            </td>
                            <td class="text-red-500 font-mono text-sm"><?php echo e($log->old_value ?? '-'); ?></td>
                            <td class="text-green-500 font-mono text-sm"><?php echo e($log->new_value ?? '-'); ?></td>
                            <td><?php echo e($log->changedByUser->name ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-gray-500 dark:text-slate-400 py-8">
                                <i class="fas fa-inbox text-3xl mb-2 opacity-50"></i>
                                <p>Belum ada log perubahan shift</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/admin/settings.blade.php ENDPATH**/ ?>