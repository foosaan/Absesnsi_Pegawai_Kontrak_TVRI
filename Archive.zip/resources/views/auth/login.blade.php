<x-guest-layout title="Login">
    <div class="card">
        <div class="card-body">
            {{-- Header --}}
            <div class="mb-6 text-center">
                <h2 class="text-2xl font-bold text-gray-900 dark:text-white">Selamat Datang</h2>
                <p class="mt-1 text-sm text-gray-500 dark:text-slate-400">Masuk ke akun Anda</p>
            </div>

            {{-- Session Status --}}
            @if(session('status'))
                <div class="notification notification-success mb-6">
                    {{ session('status') }}
                </div>
            @endif

            {{-- Validation Errors --}}
            @if($errors->any())
                <div class="notification notification-danger mb-6">
                    <ul class="list-disc list-inside text-sm">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('login') }}">
                @csrf
                <input type="hidden" name="login_type" value="user">

                {{-- NIP --}}
                <div class="form-field">
                    <label for="nip" class="form-label">NIP</label>
                    <div class="relative">
                        <span class="form-control-icon">
                            <i class="fas fa-id-card"></i>
                        </span>
                        <input 
                            id="nip"
                            type="text" 
                            name="nip" 
                            value="{{ old('nip') }}"
                            class="form-control form-control-with-icon" 
                            placeholder="Masukkan NIP Anda"
                            inputmode="numeric"
                            pattern="[0-9]*"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                            required 
                            autofocus
                        >
                    </div>
                </div>

                {{-- Password --}}
                <div class="form-field">
                    <label for="password" class="form-label">Password</label>
                    <div class="relative">
                        <span class="form-control-icon">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input 
                            id="password"
                            type="password" 
                            name="password" 
                            class="form-control form-control-with-icon" 
                            placeholder="••••••••"
                            required 
                        >
                    </div>
                </div>

                {{-- Remember Me --}}
                <div class="form-field">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input 
                            type="checkbox" 
                            name="remember" 
                            class="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-slate-600 dark:bg-slate-700"
                        >
                        <span class="text-sm text-gray-600 dark:text-slate-300">Ingat saya</span>
                    </label>
                </div>

                {{-- Submit Button --}}
                <div class="form-field">
                    <button type="submit" class="btn btn-primary w-full py-2.5">
                        <i class="fas fa-sign-in-alt"></i>
                        <span>Masuk</span>
                    </button>
                </div>

                {{-- Links --}}
                <div class="mt-4 flex flex-col items-center gap-2 text-sm">
                    @if(Route::has('password.request'))
                        <a href="{{ route('password.request') }}" class="text-blue-600 hover:text-blue-700 dark:text-blue-400">
                            Lupa password?
                        </a>
                    @endif
                </div>
            </form>
        </div>
    </div>
</x-guest-layout>