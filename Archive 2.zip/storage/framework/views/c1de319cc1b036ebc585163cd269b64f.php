<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Dashboard'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-1">
            <h1 class="page-title dark:page-title-dark">Dashboard</h1>
            <p class="text-sm text-gray-500 dark:text-gray-400">Selamat datang, <?php echo e(auth()->user()->name); ?></p>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-header flex items-center justify-between">
            <h3 class="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fas fa-id-card text-blue-500"></i>
                Profil Biodata
            </h3>
        </div>
        <div class="card-body">
            <div class="flex flex-col md:flex-row gap-8">
                
                <div class="flex flex-col items-center md:items-start shrink-0">
                    <?php if(auth()->user()->profile_photo): ?>
                        <img src="<?php echo e(asset('storage/' . auth()->user()->profile_photo)); ?>" 
                             alt="Foto Profil" 
                             class="h-24 w-24 md:h-28 md:w-28 rounded-full object-cover ring-4 ring-blue-50 dark:ring-blue-900/50 shadow-lg">
                    <?php else: ?>
                        <div class="h-24 w-24 md:h-28 md:w-28 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center ring-4 ring-blue-50 dark:ring-blue-900/50 shadow-lg">
                            <span class="text-3xl md:text-4xl font-bold text-white"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="mt-3 text-center md:text-left">
                        <p class="text-lg font-bold text-gray-900 dark:text-white"><?php echo e(auth()->user()->name); ?></p>
                        <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(auth()->user()->email); ?></p>
                        <span class="inline-block mt-1.5 badge badge-primary text-xs"><?php echo e(auth()->user()->status_pegawai ?? '-'); ?></span>
                    </div>
                </div>

                
                <div class="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="bg-gray-50 dark:bg-slate-700/40 rounded-lg px-4 py-3">
                        <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest">NIP</p>
                        <p class="text-sm font-semibold text-gray-900 dark:text-white mt-0.5"><?php echo e(auth()->user()->nip ?? '-'); ?></p>
                    </div>
                    <div class="bg-gray-50 dark:bg-slate-700/40 rounded-lg px-4 py-3">
                        <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest">NIK</p>
                        <p class="text-sm font-semibold text-gray-900 dark:text-white mt-0.5"><?php echo e(auth()->user()->nik ?? '-'); ?></p>
                    </div>
                    <div class="bg-gray-50 dark:bg-slate-700/40 rounded-lg px-4 py-3">
                        <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest">Jabatan</p>
                        <p class="text-sm font-semibold text-gray-900 dark:text-white mt-0.5"><?php echo e(auth()->user()->jabatan ?? '-'); ?></p>
                    </div>
                    <div class="bg-gray-50 dark:bg-slate-700/40 rounded-lg px-4 py-3">
                        <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest">Bagian</p>
                        <p class="text-sm font-semibold text-gray-900 dark:text-white mt-0.5"><?php echo e(auth()->user()->bagian ?? '-'); ?></p>
                    </div>
                    <div class="bg-gray-50 dark:bg-slate-700/40 rounded-lg px-4 py-3">
                        <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest">Jenis Kelamin</p>
                        <p class="text-sm font-semibold text-gray-900 dark:text-white mt-0.5"><?php echo e(auth()->user()->jenis_kelamin ?? '-'); ?></p>
                    </div>
                    <div class="bg-gray-50 dark:bg-slate-700/40 rounded-lg px-4 py-3 sm:col-span-2 lg:col-span-3">
                        <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest">Alamat</p>
                        <p class="text-sm font-semibold text-gray-900 dark:text-white mt-0.5"><?php echo e(auth()->user()->alamat ?? '-'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="grid gap-4 lg:grid-cols-3 mb-6">
        
        <div class="card">
            <div class="card-body flex items-center">
                <div class="flex items-center gap-4 w-full">
                    <?php if($todayAttendance): ?>
                        <div class="h-12 w-12 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center shrink-0">
                            <i class="fas fa-check-circle text-xl text-emerald-600 dark:text-emerald-400"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-xs text-gray-500 dark:text-gray-400">Status Absensi</p>
                            <?php if($todayAttendance->check_out_time): ?>
                                <h3 class="text-base font-bold text-emerald-600 dark:text-emerald-400">Sudah Pulang</h3>
                                <p class="text-[11px] text-gray-400 mt-0.5">
                                    <?php echo e($todayAttendance->check_in_time->format('H:i')); ?> – <?php echo e($todayAttendance->check_out_time->format('H:i')); ?>

                                    · <?php echo e($todayAttendance->check_in_time->diffForHumans($todayAttendance->check_out_time, true)); ?>

                                </p>
                            <?php else: ?>
                                <h3 class="text-base font-bold text-emerald-600 dark:text-emerald-400">Sudah Check-in</h3>
                                <p class="text-[11px] text-gray-400 mt-0.5">Masuk: <?php echo e($todayAttendance->check_in_time->format('H:i')); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center shrink-0">
                            <i class="fas fa-clock text-xl text-blue-600 dark:text-blue-400"></i>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Status Absensi</p>
                            <h3 class="text-base font-bold text-gray-900 dark:text-white">Belum Check-in</h3>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="card">
            <div class="card-body flex items-center">
                <div class="flex items-center gap-4 w-full">
                    <div class="h-12 w-12 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center shrink-0">
                        <i class="fas fa-calendar-day text-xl text-indigo-600 dark:text-indigo-400"></i>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500 dark:text-gray-400">Tanggal Hari Ini</p>
                        <h3 class="text-base font-bold text-gray-900 dark:text-white"><?php echo e(now()->translatedFormat('l, d M Y')); ?></h3>
                    </div>
                </div>
            </div>
        </div>
        
        
        <div class="card">
            <div class="card-body flex items-center justify-between">
                <div>
                    <h3 class="font-bold text-gray-900 dark:text-white">Absensi Cepat</h3>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Catat kehadiran anda</p>
                </div>
                <a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-primary flex items-center gap-2">
                    <i class="fas fa-camera"></i> <span class="hidden sm:inline">Absen</span>
                </a>
            </div>
        </div>
    </div>

    
    <?php if(auth()->user()->isShiftAttendance() && $allShifts): ?>
    <div class="card mb-6 border-l-4 border-purple-500">
        <div class="card-body">
            <div class="flex items-center justify-between mb-3">
                <h4 class="font-bold text-purple-700 dark:text-purple-400 flex items-center gap-2">
                    <i class="fas fa-shield-alt"></i> Jadwal Shift Anda
                </h4>
                <?php if($currentShift): ?>
                    <span class="badge badge-primary text-xs">
                        <i class="fas fa-clock mr-1"></i> Sekarang: <?php echo e($currentShift->name); ?>

                    </span>
                <?php else: ?>
                    <span class="badge badge-secondary text-xs">
                        <i class="fas fa-moon mr-1"></i> Di luar jam shift
                    </span>
                <?php endif; ?>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <?php $__currentLoopData = $allShifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-3 rounded-lg border transition-all <?php echo e($currentShift && $currentShift->id === $shift->id 
                        ? 'bg-purple-50 dark:bg-purple-900/30 border-purple-300 dark:border-purple-600 ring-2 ring-purple-200 dark:ring-purple-800' 
                        : 'bg-gray-50 dark:bg-slate-700/50 border-gray-200 dark:border-slate-600'); ?>">
                        <div class="flex items-center justify-between mb-1">
                            <p class="font-bold text-sm <?php echo e($currentShift && $currentShift->id === $shift->id ? 'text-purple-700 dark:text-purple-300' : 'text-gray-700 dark:text-gray-300'); ?>">
                                <?php echo e($shift->name); ?>

                            </p>
                            <?php if($currentShift && $currentShift->id === $shift->id): ?>
                                <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-200 text-purple-700 dark:bg-purple-800 dark:text-purple-300 font-semibold">AKTIF</span>
                            <?php endif; ?>
                        </div>
                        <p class="text-sm font-mono <?php echo e($currentShift && $currentShift->id === $shift->id ? 'text-purple-600 dark:text-purple-400' : 'text-gray-500 dark:text-gray-400'); ?>">
                            <i class="fas fa-clock text-[10px] mr-1"></i>
                            <?php echo e(\Carbon\Carbon::parse($shift->start_time)->format('H:i')); ?> – <?php echo e(\Carbon\Carbon::parse($shift->end_time)->format('H:i')); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php elseif(auth()->user()->isNormalAttendance() && $currentShift): ?>
    <div class="card mb-6 border-l-4 border-emerald-500">
        <div class="card-body">
            <h4 class="font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-2 mb-3">
                <i class="fas fa-calendar-alt"></i> Jadwal Kerja Anda
            </h4>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div class="bg-emerald-50 dark:bg-emerald-900/20 rounded-lg px-4 py-3">
                    <p class="text-[10px] font-semibold text-emerald-500 dark:text-emerald-500 uppercase tracking-widest">Jam Masuk</p>
                    <p class="text-lg font-bold font-mono text-emerald-700 dark:text-emerald-300 mt-0.5"><?php echo e(\Carbon\Carbon::parse($currentShift->start_time)->format('H:i')); ?></p>
                </div>
                <div class="bg-blue-50 dark:bg-blue-900/20 rounded-lg px-4 py-3">
                    <p class="text-[10px] font-semibold text-blue-500 dark:text-blue-500 uppercase tracking-widest">Jam Pulang</p>
                    <p class="text-lg font-bold font-mono text-blue-700 dark:text-blue-300 mt-0.5"><?php echo e(\Carbon\Carbon::parse($currentShift->end_time)->format('H:i')); ?></p>
                </div>
                <div class="bg-amber-50 dark:bg-amber-900/20 rounded-lg px-4 py-3">
                    <p class="text-[10px] font-semibold text-amber-500 dark:text-amber-500 uppercase tracking-widest">Toleransi</p>
                    <p class="text-lg font-bold font-mono text-amber-700 dark:text-amber-300 mt-0.5"><?php echo e($currentShift->tolerance_minutes); ?> <span class="text-xs font-normal">menit</span></p>
                </div>
                <div class="bg-gray-50 dark:bg-slate-700/50 rounded-lg px-4 py-3">
                    <p class="text-[10px] font-semibold text-gray-500 uppercase tracking-widest">Durasi</p>
                    <p class="text-lg font-bold font-mono text-gray-700 dark:text-gray-300 mt-0.5">8 <span class="text-xs font-normal">jam</span></p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="grid gap-4 sm:grid-cols-3 mb-6">
        <div class="card p-5 flex flex-row items-center justify-between">
            <div>
                <p class="text-xs font-medium text-gray-500 dark:text-slate-400">Total Hadir</p>
                <p class="mt-1 text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($stats['total_hadir'] ?? 0); ?></p>
            </div>
            <div class="h-11 w-11 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center shrink-0">
                <i class="fas fa-calendar-check text-lg text-blue-600 dark:text-blue-400"></i>
            </div>
        </div>
        <div class="card p-5 flex flex-row items-center justify-between">
            <div>
                <p class="text-xs font-medium text-gray-500 dark:text-slate-400">Tepat Waktu</p>
                <p class="mt-1 text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($stats['total_tepat_waktu'] ?? 0); ?></p>
            </div>
            <div class="h-11 w-11 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center shrink-0">
                <i class="fas fa-check-circle text-lg text-emerald-600 dark:text-emerald-400"></i>
            </div>
        </div>
        <div class="card p-5 flex flex-row items-center justify-between">
            <div>
                <p class="text-xs font-medium text-gray-500 dark:text-slate-400">Terlambat</p>
                <p class="mt-1 text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($stats['total_terlambat'] ?? 0); ?></p>
            </div>
            <div class="h-11 w-11 rounded-full bg-amber-100 dark:bg-amber-900/50 flex items-center justify-center shrink-0">
                <i class="fas fa-exclamation-circle text-lg text-amber-600 dark:text-amber-400"></i>
            </div>
        </div>
    </div>

    
    <div class="grid gap-6 lg:grid-cols-5 mb-6" x-data="{ showModal: false, photoUrl: '', photoTitle: '' }">
        
        <div class="card h-fit lg:col-span-3">
            <div class="card-header flex items-center justify-between">
                <h3 class="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fas fa-history text-blue-500 text-sm"></i>
                    Riwayat Absensi Terakhir
                </h3>
                <a href="<?php echo e(route('user.rekap')); ?>" class="text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1">
                    Lihat Semua <i class="fas fa-arrow-right text-[10px]"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <div class="divide-y divide-gray-100 dark:divide-slate-700">
                    <?php $__empty_1 = true; $__currentLoopData = $recentAttendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="px-5 py-4 hover:bg-gray-50 dark:hover:bg-slate-700/30 transition-colors">
                            <div class="flex items-start justify-between gap-4">
                                
                                <div class="flex items-center gap-3 min-w-0">
                                    <div class="h-10 w-10 rounded-lg flex items-center justify-center shrink-0
                                        <?php if($attendance->status == 'left'): ?> bg-rose-50 dark:bg-rose-900/20
                                        <?php elseif($attendance->status == 'late'): ?> bg-amber-50 dark:bg-amber-900/20
                                        <?php elseif($attendance->status == 'cuti'): ?> bg-indigo-50 dark:bg-indigo-900/20
                                        <?php elseif($attendance->status == 'dinas_luar'): ?> bg-blue-50 dark:bg-blue-900/20
                                        <?php else: ?> bg-emerald-50 dark:bg-emerald-900/20 <?php endif; ?>">
                                        <i class="fas <?php echo e($attendance->status == 'cuti' ? 'fa-calendar-minus' : ($attendance->status == 'dinas_luar' ? 'fa-briefcase' : 'fa-calendar-check')); ?> text-sm 
                                            <?php if($attendance->status == 'left'): ?> text-rose-500 dark:text-rose-400
                                            <?php elseif($attendance->status == 'late'): ?> text-amber-500 dark:text-amber-400
                                            <?php elseif($attendance->status == 'cuti'): ?> text-indigo-500 dark:text-indigo-400
                                            <?php elseif($attendance->status == 'dinas_luar'): ?> text-blue-500 dark:text-blue-400
                                            <?php else: ?> text-emerald-500 dark:text-emerald-400 <?php endif; ?>"></i>
                                    </div>
                                    <div class="min-w-0">
                                        <p class="text-sm font-semibold text-gray-900 dark:text-white">
                                            <?php echo e($attendance->check_in_time->translatedFormat('l, d M Y')); ?>

                                        </p>
                                        <div class="flex items-center gap-3 mt-1 flex-wrap">
                                            <?php if($attendance->status == 'cuti'): ?>
                                                <span class="inline-flex items-center gap-1 text-xs text-indigo-500 dark:text-indigo-400">
                                                    <i class="fas fa-calendar-minus text-[10px]"></i>
                                                    Hari Cuti
                                                </span>
                                            <?php elseif($attendance->status == 'dinas_luar'): ?>
                                                <span class="inline-flex items-center gap-1 text-xs text-blue-500 dark:text-blue-400">
                                                    <i class="fas fa-briefcase text-[10px]"></i>
                                                    Dinas Luar
                                                </span>
                                            <?php else: ?>
                                            <span class="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
                                                <i class="fas fa-sign-in-alt text-[10px]"></i>
                                                <?php echo e($attendance->check_in_time->format('H:i')); ?>

                                            </span>
                                            <?php if($attendance->check_out_time): ?>
                                                <span class="inline-flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400">
                                                    <i class="fas fa-sign-out-alt text-[10px]"></i>
                                                    <?php echo e($attendance->check_out_time->format('H:i')); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="text-xs text-gray-400">— Belum pulang</span>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if($attendance->status == 'late'): ?>
                                                <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 font-medium">Terlambat</span>
                                            <?php elseif($attendance->status == 'left'): ?>
                                                <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 font-medium">Meninggalkan Kantor</span>
                                            <?php elseif($attendance->status == 'cuti'): ?>
                                                <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 font-medium">Cuti</span>
                                            <?php elseif($attendance->status == 'dinas_luar'): ?>
                                                <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 font-medium">Dinas Luar</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <?php if(!in_array($attendance->status, ['cuti', 'dinas_luar'])): ?>
                                <div class="flex items-center gap-1.5 shrink-0">
                                    <?php if($attendance->photo_path && !in_array($attendance->photo_path, ['cuti', 'dinas_luar'])): ?>
                                        <button @click="showModal = true; photoUrl = '<?php echo e(asset('storage/' . $attendance->photo_path)); ?>'; photoTitle = 'Foto Masuk - <?php echo e($attendance->check_in_time->format('d M Y')); ?>'" 
                                                class="h-8 w-8 rounded-lg bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-900/20 dark:hover:bg-emerald-900/40 flex items-center justify-center transition-colors group"
                                                title="Lihat Foto Masuk">
                                            <i class="fas fa-camera text-[11px] text-emerald-500 group-hover:text-emerald-600 dark:text-emerald-400"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if($attendance->check_out_photo_path): ?>
                                        <button @click="showModal = true; photoUrl = '<?php echo e(asset('storage/' . $attendance->check_out_photo_path)); ?>'; photoTitle = 'Foto Pulang - <?php echo e($attendance->check_out_time->format('d M Y')); ?>'" 
                                                class="h-8 w-8 rounded-lg bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/20 dark:hover:bg-blue-900/40 flex items-center justify-center transition-colors group"
                                                title="Lihat Foto Pulang">
                                            <i class="fas fa-camera text-[11px] text-blue-500 group-hover:text-blue-600 dark:text-blue-400"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="px-5 py-10 text-center">
                            <div class="inline-flex h-14 w-14 items-center justify-center rounded-full bg-gray-100 dark:bg-slate-700 mb-3">
                                <i class="fas fa-calendar-times text-xl text-gray-400 dark:text-gray-500"></i>
                            </div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Belum ada riwayat absensi</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="card h-fit lg:col-span-2">
            <div class="card-header">
                <h3 class="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fas fa-bullhorn text-amber-500 text-sm"></i>
                    Pengumuman Terbaru
                </h3>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $announcements ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-b last:border-0 border-gray-100 dark:border-slate-700 py-4 first:pt-0 last:pb-0">
                        <h4 class="font-semibold text-gray-900 dark:text-white"><?php echo e($announcement->title); ?></h4>
                        <p class="text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed"><?php echo e(Str::limit($announcement->content, 150)); ?></p>
                        <div class="flex items-center gap-1.5 mt-2">
                             <i class="far fa-clock text-[10px] text-gray-400"></i>
                             <p class="text-[11px] text-gray-400"><?php echo e($announcement->created_at->diffForHumans()); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-10">
                        <div class="inline-flex h-14 w-14 items-center justify-center rounded-full bg-gray-100 dark:bg-slate-800 mb-3">
                            <i class="fas fa-bullhorn text-xl text-gray-400 dark:text-gray-500"></i>
                        </div>
                        <h3 class="text-sm font-medium text-gray-900 dark:text-white">Tidak ada pengumuman</h3>
                        <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Belum ada informasi terbaru.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div x-show="showModal" 
             style="display: none;"
             class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0">
            
            <div @click.away="showModal = false" 
                 class="bg-white dark:bg-slate-800 rounded-xl shadow-2xl max-w-lg w-full overflow-hidden"
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 scale-90"
                 x-transition:enter-end="opacity-100 scale-100"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-start="opacity-100 scale-100"
                 x-transition:leave-end="opacity-0 scale-90">
                
                <div class="flex items-center justify-between p-4 border-b border-gray-100 dark:border-slate-700">
                    <h3 class="font-bold text-gray-900 dark:text-white" x-text="photoTitle">Foto Absensi</h3>
                    <button @click="showModal = false" class="h-8 w-8 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center justify-center transition-colors">
                        <i class="fas fa-times text-gray-400"></i>
                    </button>
                </div>
                
                <div class="p-4 flex justify-center bg-gray-50 dark:bg-slate-900/50">
                    <img :src="photoUrl" class="max-h-[70vh] rounded-lg shadow-sm" alt="Foto Absensi">
                </div>
                
                <div class="p-4 border-t border-gray-100 dark:border-slate-700 flex justify-end">
                    <button @click="showModal = false" class="btn btn-secondary">Tutup</button>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/dashboard.blade.php ENDPATH**/ ?>