<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Jenis Potongan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100 dark:bg-red-900">
                    <i class="fas fa-minus-circle text-red-600 dark:text-red-400"></i>
                </div>
                <div>
                    <h1 class="page-title dark:page-title-dark">Jenis Potongan</h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        Kelola jenis potongan gaji intern
                    </p>
                </div>
            </div>
            <button onclick="document.getElementById('addDeductionModal').classList.remove('hidden')" class="btn btn-primary">
                <i class="fas fa-plus"></i>
                <span>Tambah Potongan</span>
            </button>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="card dark:card-dark">
        <div class="overflow-x-auto">
            <table class="table dark:table-dark">
                <thead>
                    <tr>
                        <th class="w-16">No</th>
                        <th>Nama Potongan</th>
                        <th>Deskripsi</th>
                        <th class="text-center w-32">Aksi</th>
                    </tr>
                </thead>
                <tbody class="dark:text-gray-300">
                    <?php $__empty_1 = true; $__currentLoopData = $deductionTypes ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="font-medium text-gray-900 dark:text-white"><?php echo e($type->name); ?></td>
                        <td><?php echo e($type->description ?? '-'); ?></td>
                        <td class="text-center">
                            <div class="flex items-center justify-center gap-2">
                                <button onclick="editDeduction(<?php echo e($type->id); ?>, '<?php echo e($type->name); ?>', '<?php echo e($type->description); ?>')" 
                                        class="text-amber-500 hover:text-amber-600 dark:hover:text-amber-400 btn-icon">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form action="<?php echo e(route('staff.keuangan.deductions.destroy', $type)); ?>" method="POST"
                                      data-confirm="Yakin ingin menghapus jenis potongan ini?" data-confirm-title="Konfirmasi Hapus">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 btn-icon">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-8 text-gray-500 dark:text-gray-400">
                            <i class="fas fa-inbox text-4xl mb-3 opacity-50"></i>
                            <p>Belum ada jenis potongan.</p>
                            <button onclick="document.getElementById('addDeductionModal').classList.remove('hidden')" class="text-blue-600 hover:underline mt-2">
                                Tambah Baru
                            </button>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div id="addDeductionModal" class="fixed inset-0 z-50 hidden bg-gray-900/50 flex items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md transform transition-all">
            <div class="px-6 py-4 border-b dark:border-slate-700 flex justify-between items-center">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Tambah Jenis Potongan</h3>
                <button onclick="document.getElementById('addDeductionModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-500">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form action="<?php echo e(route('staff.keuangan.deductions.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="p-6 space-y-4">
                    <div class="form-group">
                        <label class="form-label">Nama Potongan</label>
                        <input type="text" name="name" class="form-control" required placeholder="Contoh: Koperasi, Denda, dll">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="px-6 py-4 bg-gray-50 dark:bg-slate-700/50 rounded-b-lg flex justify-end gap-3">
                    <button type="button" onclick="document.getElementById('addDeductionModal').classList.add('hidden')" class="btn btn-secondary">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <div id="editDeductionModal" class="fixed inset-0 z-50 hidden bg-gray-900/50 flex items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md transform transition-all">
            <div class="px-6 py-4 border-b dark:border-slate-700 flex justify-between items-center">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Edit Jenis Potongan</h3>
                <button onclick="document.getElementById('editDeductionModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-500">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="editForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="p-6 space-y-4">
                    <div class="form-group">
                        <label class="form-label">Nama Potongan</label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="px-6 py-4 bg-gray-50 dark:bg-slate-700/50 rounded-b-lg flex justify-end gap-3">
                    <button type="button" onclick="document.getElementById('editDeductionModal').classList.add('hidden')" class="btn btn-secondary">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Update
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        function editDeduction(id, name, description) {
            document.getElementById('editForm').action = `/staff/keuangan/deductions/${id}`;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_description').value = description;
            document.getElementById('editDeductionModal').classList.remove('hidden');
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/keuangan/deductions/index.blade.php ENDPATH**/ ?>