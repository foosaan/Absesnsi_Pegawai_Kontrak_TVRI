<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Input Gaji'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900">
                    <i class="fas fa-edit text-blue-600 dark:text-blue-400"></i>
                </div>
                <div>
                    <h1 class="page-title dark:page-title-dark">Input Gaji</h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        <?php echo e(\Carbon\Carbon::create()->month((int) $month)->translatedFormat('F')); ?> <?php echo e($year); ?>

                    </p>
                </div>
            </div>
            <a href="<?php echo e(route('staff.keuangan.dashboard')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i>
                <span>Kembali</span>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('staff.keuangan.salaries.input')); ?>" class="flex flex-wrap items-end gap-4">
                <div class="form-group mb-0 min-w-32">
                    <label class="form-label">Bulan</label>
                    <select name="month" class="form-control" onchange="this.form.submit()">
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                                <?php echo e(\Carbon\Carbon::create()->month((int) $m)->translatedFormat('F')); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group mb-0 min-w-24">
                    <label class="form-label">Tahun</label>
                    <select name="year" class="form-control" onchange="this.form.submit()">
                        <?php for($y = date('Y'); $y >= 2020; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

            </form>
        </div>
    </div>

    
    <div class="card mb-6">
        <div class="card-body">
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Progress Input</span>
                <span class="text-sm font-bold text-gray-900 dark:text-white">
                    <?php echo e($completedCount ?? 0); ?> / <?php echo e($totalUsers ?? 0); ?> karyawan
                </span>
            </div>
            <div class="progress">
                <?php 
                    $totalUsersValue = $totalUsers ?? 0;
                    $completedValue = $completedCount ?? 0;
                    $percent = $totalUsersValue > 0 ? ($completedValue / $totalUsersValue) * 100 : 0; 
                ?>
                <div class="progress-bar bg-emerald-500" style="width: <?php echo e($percent); ?>%"></div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-users text-blue-500 mr-2"></i>
                Daftar Karyawan
            </h3>
        </div>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Karyawan</th>
                        <th>Bagian</th>
                        <th>Gaji Pokok</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="dark:text-gray-300">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e((method_exists($users, 'firstItem') ? $users->firstItem() : 1) + $index); ?></td>
                        <td>
                            <div class="flex items-center gap-3">
                                <div class="avatar avatar-sm <?php echo e($user->salary_exists ? 'bg-emerald-600' : 'bg-blue-600'); ?> text-white">
                                    <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white"><?php echo e($user->name); ?></p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($user->nip ?? '-'); ?></p>
                                </div>
                            </div>
                        </td>
                        <td><?php echo e($user->bagian ?? '-'); ?></td>
                        <td>Rp <?php echo e(number_format($user->gaji_pokok ?? 0, 0, ',', '.')); ?></td>
                        <td>
                            <?php if($user->salary_exists): ?>
                                <span class="badge badge-success">
                                    <i class="fas fa-check mr-1"></i> Sudah Input
                                </span>
                            <?php else: ?>
                                <span class="badge badge-warning">
                                    <i class="fas fa-clock mr-1"></i> Belum Input
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if($user->salary_exists): ?>
                                <a href="<?php echo e(route('staff.keuangan.salaries.show', $user->salary_id)); ?>" 
                                   class="btn btn-sm btn-primary">
                                    <i class="fas fa-eye"></i>
                                    <span>Lihat</span>
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('staff.keuangan.salaries.input.single', ['user' => $user->id, 'month' => $month, 'year' => $year])); ?>" 
                                   class="btn btn-sm btn-success">
                                    <i class="fas fa-plus"></i>
                                    <span>Input</span>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-8 text-gray-500 dark:text-gray-400">
                            <i class="fas fa-users-slash text-4xl mb-3 opacity-50"></i>
                            <p>Tidak ada data karyawan</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if(method_exists($users, 'hasPages') && $users->hasPages()): ?>
        <div class="card-body border-t dark:border-slate-700">
            <?php echo e($users->appends(request()->query())->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/staff/keuangan/salaries/input-list.blade.php ENDPATH**/ ?>