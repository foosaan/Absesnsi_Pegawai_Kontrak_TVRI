<section>
    <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">
        Gunakan password yang panjang dan unik agar akun Anda tetap aman.
    </p>

    <form method="post" action="<?php echo e(route('password.update')); ?>" class="space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="form-group">
            <label for="update_password_current_password" class="form-label dark:text-gray-300">Password Saat Ini</label>
            <div class="relative">
                <i class="fas fa-key form-control-icon"></i>
                <input id="update_password_current_password" name="current_password" type="password" 
                       class="form-control form-control-with-icon" autocomplete="current-password">
            </div>
            <?php $__errorArgs = ['current_password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="update_password_password" class="form-label dark:text-gray-300">Password Baru</label>
            <div class="relative">
                <i class="fas fa-lock form-control-icon"></i>
                <input id="update_password_password" name="password" type="password" 
                       class="form-control form-control-with-icon" autocomplete="new-password">
            </div>
            <?php $__errorArgs = ['password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="update_password_password_confirmation" class="form-label dark:text-gray-300">Konfirmasi Password</label>
            <div class="relative">
                <i class="fas fa-lock form-control-icon"></i>
                <input id="update_password_password_confirmation" name="password_confirmation" type="password" 
                       class="form-control form-control-with-icon" autocomplete="new-password">
            </div>
            <?php $__errorArgs = ['password_confirmation', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex items-center gap-4 pt-2">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save mr-1"></i> Simpan
            </button>

            <?php if(session('status') === 'password-updated'): ?>
                <p x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 2000)"
                   class="text-sm text-green-600 dark:text-green-400">
                    <i class="fas fa-check-circle mr-1"></i> Password berhasil diubah.
                </p>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>