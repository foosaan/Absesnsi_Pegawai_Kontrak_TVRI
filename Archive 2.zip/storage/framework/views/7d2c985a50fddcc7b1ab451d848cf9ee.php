<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Admin Dashboard'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">Dashboard Admin</h1>
     <?php $__env->endSlot(); ?>

    
    <div class="mb-6 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        
        <div class="card">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Total Pegawai</p>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white"><?php echo e($users->count()); ?></p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
                        <i class="fas fa-users text-xl text-blue-600 dark:text-blue-400"></i>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Hadir Hari Ini</p>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white">
                            <?php echo e($attendances->where('check_in_time', '>=', now()->startOfDay())->count()); ?>

                        </p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900">
                        <i class="fas fa-check-circle text-xl text-green-600 dark:text-green-400"></i>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Terlambat</p>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white">
                            <?php echo e($attendances->where('status', 'late')->count()); ?>

                        </p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-full bg-yellow-100 dark:bg-yellow-900">
                        <i class="fas fa-clock text-xl text-yellow-600 dark:text-yellow-400"></i>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Shift Aktif</p>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white"><?php echo e($shifts->count()); ?></p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-full bg-purple-100 dark:bg-purple-900">
                        <i class="fas fa-calendar-alt text-xl text-purple-600 dark:text-purple-400"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-6">
        <div class="card-header">
            <h3 class="card-title">Data Absensi</h3>
        </div>
        <div class="card-body">
            
            <form method="GET" action="<?php echo e(route('admin.dashboard')); ?>" class="mb-6 flex flex-wrap gap-4">
                <div class="form-field mb-0">
                    <label for="filter_date" class="form-label">Tanggal</label>
                    <input type="date" name="filter_date" id="filter_date" value="<?php echo e(request('filter_date')); ?>" class="form-control" onchange="this.form.submit()">
                </div>
                <div class="form-field mb-0">
                    <label for="filter_user" class="form-label">Pegawai</label>
                    <select name="filter_user" id="filter_user" class="form-control" onchange="this.form.submit()">
                        <option value="">Semua Pegawai</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(request('filter_user') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </form>

            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Pegawai</th>
                            <th>Tanggal</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                            <th>Shift</th>
                            <th>Status</th>
                            <th>Foto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="font-medium text-gray-900 dark:text-white"><?php echo e($attendance->user->name ?? '-'); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo e($attendance->user->nip ?? ''); ?></div>
                                </td>
                                <td><?php echo e($attendance->check_in_time ? $attendance->check_in_time->format('d M Y') : '-'); ?></td>
                                <td><?php echo e($attendance->check_in_time ? $attendance->check_in_time->format('H:i') : '-'); ?></td>
                                <td><?php echo e($attendance->check_out_time ? $attendance->check_out_time->format('H:i') : '-'); ?></td>
                                <td><?php echo e($attendance->shift->name ?? '-'); ?></td>
                                <td>
                                    <?php if($attendance->status == 'present'): ?>
                                        <span class="badge badge-success">Hadir</span>
                                    <?php elseif($attendance->status == 'late'): ?>
                                        <span class="badge badge-warning">Terlambat</span>
                                    <?php elseif($attendance->status == 'left'): ?>
                                        <span class="badge badge-danger">Meninggalkan Kantor</span>
                                    <?php elseif($attendance->status == 'cuti'): ?>
                                        <span class="badge" style="background-color: rgb(238 242 255); color: rgb(67 56 202);">Cuti</span>
                                    <?php elseif($attendance->status == 'absent'): ?>
                                        <span class="badge badge-danger">Tidak Hadir</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><?php echo e($attendance->status ?? '-'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($attendance->check_in_photo): ?>
                                        <img src="<?php echo e(asset('storage/' . $attendance->check_in_photo)); ?>" alt="Check In" class="h-10 w-10 rounded-lg object-cover">
                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-gray-500 dark:text-slate-400">
                                    Tidak ada data absensi
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Log Perubahan Shift</h3>
        </div>
        <div class="card-body">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Waktu</th>
                            <th>Shift</th>
                            <th>Diubah Oleh</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $shiftLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->created_at->format('d M Y H:i')); ?></td>
                                <td><?php echo e($log->shift->name ?? '-'); ?></td>
                                <td><?php echo e($log->changedByUser->name ?? '-'); ?></td>
                                <td><?php echo e($log->action ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-gray-500 dark:text-slate-400">
                                    Tidak ada log perubahan shift
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>