<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Rekap Absensi'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-3">
            <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-100 dark:bg-purple-900">
                <i class="fas fa-chart-bar text-purple-600 dark:text-purple-400"></i>
            </div>
            <div>
                <h1 class="page-title">Rekap Absensi</h1>
                <p class="text-sm text-gray-500 dark:text-gray-400">
                    <?php echo e(DateTime::createFromFormat('!m', $month)->format('F')); ?> <?php echo e($year); ?>

                </p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-body">
            <div class="flex flex-wrap items-end justify-between gap-4">
                <form method="GET" class="flex flex-wrap items-end gap-4">
                    <div class="form-field mb-0">
                        <label class="form-label">Bulan</label>
                        <select name="month" class="form-control" onchange="this.form.submit()">
                            <?php for($m = 1; $m <= 12; $m++): ?>
                                <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                                    <?php echo e(DateTime::createFromFormat('!m', $m)->format('F')); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-field mb-0">
                        <label class="form-label">Tahun</label>
                        <select name="year" class="form-control" onchange="this.form.submit()">
                            <?php for($y = 2024; $y <= 2030; $y++): ?>
                                <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="card mb-6" x-data="{ filterType: 'month' }">
        <div class="card-header">
            <h3 class="font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-download text-green-500 mr-2"></i>
                Download Rekap Absensi
            </h3>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('user.rekap.export')); ?>" class="space-y-4">
                
                <div class="flex flex-wrap items-center gap-3">
                    <label class="form-label mb-0 mr-2">Tipe Download:</label>
                    <label class="inline-flex items-center gap-1.5 cursor-pointer px-3 py-1.5 rounded-lg border transition-colors"
                           :class="filterType === 'day' ? 'bg-emerald-50 border-emerald-300 text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-600 dark:text-emerald-400' : 'border-gray-200 dark:border-slate-600 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-700'">
                        <input type="radio" name="filter_type" value="day" x-model="filterType" class="hidden">
                        <i class="fas fa-calendar-day text-xs"></i>
                        <span class="text-sm font-medium">Per Hari</span>
                    </label>
                    <label class="inline-flex items-center gap-1.5 cursor-pointer px-3 py-1.5 rounded-lg border transition-colors"
                           :class="filterType === 'month' ? 'bg-emerald-50 border-emerald-300 text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-600 dark:text-emerald-400' : 'border-gray-200 dark:border-slate-600 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-700'">
                        <input type="radio" name="filter_type" value="month" x-model="filterType" class="hidden">
                        <i class="fas fa-calendar-alt text-xs"></i>
                        <span class="text-sm font-medium">Per Bulan</span>
                    </label>
                    <label class="inline-flex items-center gap-1.5 cursor-pointer px-3 py-1.5 rounded-lg border transition-colors"
                           :class="filterType === 'all' ? 'bg-emerald-50 border-emerald-300 text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-600 dark:text-emerald-400' : 'border-gray-200 dark:border-slate-600 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-700'">
                        <input type="radio" name="filter_type" value="all" x-model="filterType" class="hidden">
                        <i class="fas fa-layer-group text-xs"></i>
                        <span class="text-sm font-medium">Semua Data</span>
                    </label>
                </div>

                
                <div class="flex flex-wrap items-end gap-4">
                    
                    <div class="form-group mb-0" x-show="filterType === 'day'" x-cloak>
                        <label class="form-label">Tanggal</label>
                        <input type="date" name="date" value="<?php echo e(now()->toDateString()); ?>" class="form-control">
                    </div>

                    
                    <div class="form-group mb-0" x-show="filterType === 'month'" x-cloak>
                        <label class="form-label">Bulan</label>
                        <select name="month" class="form-control">
                            <?php for($m = 1; $m <= 12; $m++): ?>
                                <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                                    <?php echo e(DateTime::createFromFormat('!m', $m)->format('F')); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group mb-0" x-show="filterType === 'month'" x-cloak>
                        <label class="form-label">Tahun</label>
                        <select name="year" class="form-control">
                            <?php for($y = 2024; $y <= 2030; $y++): ?>
                                <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    
                    <div x-show="filterType === 'all'" x-cloak>
                        <p class="text-sm text-gray-500 dark:text-gray-400 py-2">
                            <i class="fas fa-info-circle mr-1"></i> Semua data absensi Anda akan didownload
                        </p>
                    </div>

                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-file-excel mr-1"></i> Download Excel
                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <div class="grid gap-4 sm:grid-cols-3 mb-6">
        <div class="stat-card">
            <div>
                <p class="stat-card-label">Total Hadir</p>
                <p class="stat-card-value"><?php echo e($stats['total_hadir']); ?></p>
            </div>
            <div class="stat-card-icon bg-blue-100 dark:bg-blue-900">
                <i class="fas fa-calendar-check text-xl text-blue-600 dark:text-blue-400"></i>
            </div>
        </div>
        <div class="stat-card">
            <div>
                <p class="stat-card-label">Tepat Waktu</p>
                <p class="stat-card-value"><?php echo e($stats['total_tepat_waktu']); ?></p>
            </div>
            <div class="stat-card-icon bg-emerald-100 dark:bg-emerald-900">
                <i class="fas fa-check-circle text-xl text-emerald-600 dark:text-emerald-400"></i>
            </div>
        </div>
        <div class="stat-card">
            <div>
                <p class="stat-card-label">Terlambat</p>
                <p class="stat-card-value"><?php echo e($stats['total_terlambat']); ?></p>
            </div>
            <div class="stat-card-icon bg-amber-100 dark:bg-amber-900">
                <i class="fas fa-exclamation-circle text-xl text-amber-600 dark:text-amber-400"></i>
            </div>
        </div>
    </div>

    
    <div class="card" x-data="{ showModal: false, photoUrl: '', photoTitle: '' }">
        <div class="card-header flex items-center justify-between">
            <h3 class="card-title flex items-center gap-2">
                <i class="fas fa-list-alt text-purple-500 text-sm"></i>
                Riwayat Absensi
            </h3>
            <span class="text-xs text-gray-400 dark:text-gray-500"><?php echo e($attendances->count()); ?> data</span>
        </div>
        <div class="card-body p-0">
            <div class="divide-y divide-gray-100 dark:divide-slate-700">
                <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="px-5 py-4 hover:bg-gray-50 dark:hover:bg-slate-700/30 transition-colors">
                        <div class="flex items-start justify-between gap-4">
                            
                            <div class="flex items-start gap-3 min-w-0 flex-1">
                                <div class="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 mt-0.5
                                    <?php if($attendance->status === 'left'): ?> bg-rose-50 dark:bg-rose-900/20
                                    <?php elseif($attendance->status === 'late'): ?> bg-amber-50 dark:bg-amber-900/20
                                    <?php elseif($attendance->status === 'cuti'): ?> bg-indigo-50 dark:bg-indigo-900/20
                                    <?php elseif($attendance->status === 'dinas_luar'): ?> bg-blue-50 dark:bg-blue-900/20
                                    <?php else: ?> bg-emerald-50 dark:bg-emerald-900/20 <?php endif; ?>">
                                    <i class="fas <?php echo e(in_array($attendance->status, ['cuti', 'dinas_luar']) ? ($attendance->status === 'dinas_luar' ? 'fa-briefcase' : 'fa-calendar-minus') : 'fa-calendar-check'); ?> text-sm 
                                        <?php if($attendance->status === 'left'): ?> text-rose-500 dark:text-rose-400
                                        <?php elseif($attendance->status === 'late'): ?> text-amber-500 dark:text-amber-400
                                        <?php elseif($attendance->status === 'cuti'): ?> text-indigo-500 dark:text-indigo-400
                                        <?php elseif($attendance->status === 'dinas_luar'): ?> text-blue-500 dark:text-blue-400
                                        <?php else: ?> text-emerald-500 dark:text-emerald-400 <?php endif; ?>"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <div class="flex items-center gap-2 flex-wrap">
                                        <p class="text-sm font-semibold text-gray-900 dark:text-white">
                                            <?php echo e($attendance->check_in_time->translatedFormat('l, d M Y')); ?>

                                        </p>
                                        <?php if($attendance->shift): ?>
                                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-gray-100 dark:bg-slate-600 text-gray-500 dark:text-gray-300 font-medium">
                                                <?php echo e($attendance->shift->name); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex items-center gap-4 mt-1.5 flex-wrap">
                                        <?php if($attendance->status === 'cuti'): ?>
                                            <span class="inline-flex items-center gap-1 text-xs text-indigo-500 dark:text-indigo-400">
                                                <i class="fas fa-calendar-minus text-[10px]"></i>
                                                Hari Cuti
                                            </span>
                                        <?php elseif($attendance->status === 'dinas_luar'): ?>
                                            <span class="inline-flex items-center gap-1 text-xs text-blue-500 dark:text-blue-400">
                                                <i class="fas fa-briefcase text-[10px]"></i>
                                                Dinas Luar
                                            </span>
                                        <?php else: ?>
                                        
                                        <div class="flex items-center gap-2">
                                            <span class="inline-flex items-center gap-1 text-xs">
                                                <i class="fas fa-sign-in-alt text-[10px] text-emerald-500"></i>
                                                <span class="badge badge-success text-xs"><?php echo e($attendance->check_in_time->format('H:i')); ?></span>
                                            </span>
                                            <?php if($attendance->photo_path && !in_array($attendance->photo_path, ['cuti', 'dinas_luar'])): ?>
                                                <button @click="showModal = true; photoUrl = '<?php echo e(asset('storage/' . $attendance->photo_path)); ?>'; photoTitle = 'Foto Masuk - <?php echo e($attendance->check_in_time->format('d M Y')); ?>'" 
                                                        class="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-400 dark:hover:bg-emerald-900/40 transition-colors cursor-pointer"
                                                        title="Foto Masuk">
                                                    <i class="fas fa-camera text-[8px]"></i> Foto
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="flex items-center gap-2">
                                            <?php if($attendance->check_out_time): ?>
                                                <span class="inline-flex items-center gap-1 text-xs">
                                                    <i class="fas fa-sign-out-alt text-[10px] text-blue-500"></i>
                                                    <span class="badge badge-info text-xs"><?php echo e($attendance->check_out_time->format('H:i')); ?></span>
                                                </span>
                                                <?php if($attendance->check_out_photo_path): ?>
                                                    <button @click="showModal = true; photoUrl = '<?php echo e(asset('storage/' . $attendance->check_out_photo_path)); ?>'; photoTitle = 'Foto Pulang - <?php echo e($attendance->check_out_time->format('d M Y')); ?>'" 
                                                            class="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400 dark:hover:bg-blue-900/40 transition-colors cursor-pointer"
                                                            title="Foto Pulang">
                                                        <i class="fas fa-camera text-[8px]"></i> Foto
                                                    </button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-xs text-gray-400">
                                                    <i class="fas fa-sign-out-alt text-[10px] mr-1"></i> —
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="shrink-0">
                                <?php if($attendance->status === 'late'): ?>
                                    <span class="badge badge-warning">Terlambat</span>
                                <?php elseif($attendance->status === 'left'): ?>
                                    <span class="badge badge-danger">Meninggalkan Kantor</span>
                                <?php elseif($attendance->status === 'cuti'): ?>
                                    <span class="badge" style="background-color: rgb(238 242 255); color: rgb(67 56 202);">Cuti</span>
                                <?php elseif($attendance->status === 'dinas_luar'): ?>
                                    <span class="badge" style="background-color: rgb(219 234 254); color: rgb(29 78 216);">Dinas Luar</span>
                                <?php else: ?>
                                    <span class="badge badge-success">Hadir</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="px-5 py-12 text-center">
                        <div class="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gray-100 dark:bg-slate-700 mb-3">
                            <i class="fas fa-calendar-times text-2xl text-gray-400 dark:text-gray-500"></i>
                        </div>
                        <p class="font-medium text-gray-900 dark:text-white">Tidak ada data absensi</p>
                        <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Belum ada riwayat untuk periode ini</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div x-show="showModal" 
             style="display: none;"
             class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0">
            
            <div @click.away="showModal = false" 
                 class="bg-white dark:bg-slate-800 rounded-xl shadow-2xl max-w-lg w-full overflow-hidden"
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 scale-90"
                 x-transition:enter-end="opacity-100 scale-100"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-start="opacity-100 scale-100"
                 x-transition:leave-end="opacity-0 scale-90">
                
                <div class="flex items-center justify-between p-4 border-b border-gray-100 dark:border-slate-700">
                    <h3 class="font-bold text-gray-900 dark:text-white" x-text="photoTitle">Foto Absensi</h3>
                    <button @click="showModal = false" class="h-8 w-8 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center justify-center transition-colors">
                        <i class="fas fa-times text-gray-400"></i>
                    </button>
                </div>
                
                <div class="p-4 flex justify-center bg-gray-50 dark:bg-slate-900/50">
                    <img :src="photoUrl" class="max-h-[70vh] rounded-lg shadow-sm" alt="Foto Absensi">
                </div>
                
                <div class="p-4 border-t border-gray-100 dark:border-slate-700 flex justify-end">
                    <button @click="showModal = false" class="btn btn-secondary">Tutup</button>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/user/rekap.blade.php ENDPATH**/ ?>