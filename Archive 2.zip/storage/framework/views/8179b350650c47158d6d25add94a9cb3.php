<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Log Aktivitas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">Log Aktivitas</h1>
     <?php $__env->endSlot(); ?>

    
    <div class="card mb-6">
        <div class="card-body">
            <form method="GET" class="flex flex-wrap gap-4 items-end">
                <div class="form-field mb-0">
                    <label class="form-label">Aksi</label>
                    <select name="action" class="form-control" onchange="this.form.submit()">
                        <option value="">Semua</option>
                        <option value="create" <?php echo e(request('action') == 'create' ? 'selected' : ''); ?>>Create</option>
                        <option value="update" <?php echo e(request('action') == 'update' ? 'selected' : ''); ?>>Update</option>
                        <option value="delete" <?php echo e(request('action') == 'delete' ? 'selected' : ''); ?>>Delete</option>
                    </select>
                </div>
                <div class="form-field mb-0">
                    <label class="form-label">Tanggal</label>
                    <input type="date" name="date" value="<?php echo e(request('date')); ?>" class="form-control" onchange="this.form.submit()">
                </div>
                <div class="flex gap-2">
                    <a href="<?php echo e(route('admin.activity-logs')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Riwayat Aktivitas</h3>
        </div>
        <div class="card-body p-0">
            <ul class="divide-y divide-gray-200 dark:divide-slate-700">
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="px-6 py-4 hover:bg-gray-50 dark:hover:bg-slate-700/50">
                    <div class="flex items-start gap-4">
                        <div class="flex-shrink-0">
                            <?php if($log->action == 'create'): ?>
                                <div class="flex h-10 w-10 items-center justify-center rounded-full bg-green-100 dark:bg-green-900">
                                    <i class="fas fa-plus text-green-600 dark:text-green-400"></i>
                                </div>
                            <?php elseif($log->action == 'update'): ?>
                                <div class="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
                                    <i class="fas fa-edit text-blue-600 dark:text-blue-400"></i>
                                </div>
                            <?php elseif($log->action == 'delete'): ?>
                                <div class="flex h-10 w-10 items-center justify-center rounded-full bg-red-100 dark:bg-red-900">
                                    <i class="fas fa-trash text-red-600 dark:text-red-400"></i>
                                </div>
                            <?php else: ?>
                                <div class="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700">
                                    <i class="fas fa-info text-gray-600 dark:text-gray-400"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2">
                                <?php if($log->action == 'create'): ?>
                                    <span class="badge badge-success">Create</span>
                                <?php elseif($log->action == 'update'): ?>
                                    <span class="badge badge-primary">Update</span>
                                <?php elseif($log->action == 'delete'): ?>
                                    <span class="badge badge-danger">Delete</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary"><?php echo e(ucfirst($log->action)); ?></span>
                                <?php endif; ?>
                                <span class="text-sm text-gray-500 dark:text-slate-400"><?php echo e(class_basename($log->model_type)); ?></span>
                            </div>
                            <p class="mt-1 text-sm text-gray-900 dark:text-white"><?php echo e($log->description); ?></p>
                            <div class="mt-2 flex items-center gap-4 text-xs text-gray-500 dark:text-slate-400">
                                <span><i class="fas fa-user mr-1"></i> <?php echo e($log->user->name ?? 'System'); ?></span>
                                <span><i class="fas fa-clock mr-1"></i> <?php echo e($log->created_at->format('d M Y H:i')); ?></span>
                                <?php if($log->ip_address): ?>
                                <span><i class="fas fa-globe mr-1"></i> <?php echo e($log->ip_address); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="px-6 py-10 text-center text-gray-500 dark:text-slate-400">
                    <i class="fas fa-history text-4xl mb-2 opacity-50"></i>
                    <p>Belum ada aktivitas tercatat</p>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        
        <?php if($logs->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($logs->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/admin/DATA D/KULIAH/tvri/absensi/resources/views/admin/activity-logs.blade.php ENDPATH**/ ?>